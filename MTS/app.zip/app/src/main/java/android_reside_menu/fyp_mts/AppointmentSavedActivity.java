package android_reside_menu.fyp_mts;

import android.content.Context;
import android.content.Intent;
import android.speech.tts.TextToSpeech;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.Locale;

public class AppointmentSavedActivity extends AppCompatActivity implements TextToSpeech.OnInitListener{

    Button backHomeBtn;
    String yearValue;
    String monthValue;
    String dateValue;
    String hourValue;
    String minuteValue;
    String dataString;
    String uniqueAudioID;


    private TextToSpeech tts;
    private static final String bmSave = "myFile.txt";
    private static final String TAG = AppointmentReminderActivity.class.getName();



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_appointment_saved);
        tts = new TextToSpeech(this, this);


        Bundle bundle = getIntent().getExtras();
        yearValue = bundle.getString("year_value");
        monthValue = bundle.getString("month_value");
        dateValue = bundle.getString("date_value");
        hourValue = bundle.getString("hour_value");
        minuteValue = bundle.getString("minute_value");
        uniqueAudioID = bundle.getString("audio_value");


        backHomeBtn = (Button)findViewById(R.id.back_Home);

        backHomeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mainSpeak();
            }
        });

        //dataString=yearValue + " "+monthValue + " "+ dateValue +" "+ hourValue + ":"+ minuteValue;
        dataString=dateValue + " "+monthValue + " "+ yearValue +" "+ hourValue + ":"+ minuteValue;

        writeToFile(dataString);







        backHomeBtn.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v){
                Intent intent1 = new Intent(AppointmentSavedActivity.this, MainActivity.class);
                Bundle bundle = new Bundle();
                bundle.putString("year_value", yearValue);
                bundle.putString("month_value", monthValue);
                bundle.putString("date_value", dateValue);
                bundle.putString("hour_value", hourValue);
                bundle.putString("minute_value", minuteValue);
                bundle.putString("audio_value", uniqueAudioID);
                intent1.putExtras(bundle);
                startActivity(intent1);
                return true;
            }
        });


    }

    private void writeToFile(String data) {
        try {
            OutputStreamWriter outputStreamWriter = new OutputStreamWriter(openFileOutput(bmSave, Context.MODE_APPEND));
            outputStreamWriter.write(data);
            outputStreamWriter.write("\r\n");
            outputStreamWriter.close();
        }
        catch (IOException e) {
            Log.e(TAG,"File write failed: "+e.toString());
        }

    }


    private void mainSpeak() {
        String text= "Pelantikan anda telah Disimpan.. Sila tekan skrin untuk kembali ke halaman utama...";
        tts.speak(text,TextToSpeech.QUEUE_FLUSH,null);
    }

    @Override
    protected void onStop()
    {
        super.onStop();

        if(tts != null){
            tts.shutdown();
        }
    }

    @Override
    public void onInit(int status) {
        if (status == TextToSpeech.SUCCESS) {
            int result = tts.setLanguage(new Locale("id","ID"));
            if (result == TextToSpeech.LANG_NOT_SUPPORTED || result == TextToSpeech.LANG_MISSING_DATA) {
                Log.e("TTS","This Language is not supported");
            }
            else{
                mainSpeak();
            }
        }else{
            Log.e("TTS", "Initialization_Failed");
        }

    }
}
