package android_reside_menu.fyp_mts;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.os.Environment;
import android.speech.tts.TextToSpeech;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import java.io.IOException;
import java.util.Locale;

public class RecordDetailActivity extends AppCompatActivity implements TextToSpeech.OnInitListener {

    private TextToSpeech tts;
    Button previousPageRecord;
    Button nextPageRecord;
    Button playRecord;
    TextView emptyView;
    String pathSave = " ";
    MediaRecorder mediaRecorder;
    MediaPlayer mediaPlayer;
    String yearValue;
    String monthValue;
    String dateValue;
    String hourValue;
    String minuteValue;
    String uniqueAudioID;
    boolean mediaIsRecording = false;


    final int REQUEST_PERMISSION_CODE = 1000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_record_detail);


        Bundle bundle = getIntent().getExtras();
        yearValue = bundle.getString("year_value");
        monthValue = bundle.getString("month_value");
        dateValue = bundle.getString("date_value");
        hourValue = bundle.getString("hour_value");
        minuteValue = bundle.getString("minute_value");

        uniqueAudioID = dateValue + monthValue + yearValue + hourValue + minuteValue;


        previousPageRecord = (Button) findViewById(R.id.button_previous);
        nextPageRecord = (Button) findViewById(R.id.button_next);
        playRecord = (Button) findViewById(R.id.button_play_stop);
        emptyView = (TextView) findViewById(R.id.emptyView);


        tts = new TextToSpeech(this, this);


        playRecord.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                mediaPlayer = new MediaPlayer();
                try {
                    mediaPlayer.setDataSource(pathSave);
                    mediaPlayer.prepare();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                mediaPlayer.start();
                return true;
            }
        });

        emptyView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mainSpeak();
            }
        });

        playRecord.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                playRecordSpeak();
            }
        });

        previousPageRecord.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                previousPageRecordSpeak();
            }
        });

        previousPageRecord.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                finish();
                return true;
            }
        });

        nextPageRecord.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                nextPageRecordSpeak();
            }
        });

        nextPageRecord.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {


                Intent intent1 = new Intent(RecordDetailActivity.this, AppointmentReminderActivity.class);
                Bundle bundle = new Bundle();
                bundle.putString("year_value", yearValue);
                bundle.putString("month_value", monthValue);
                bundle.putString("date_value", dateValue);
                bundle.putString("hour_value", hourValue);
                bundle.putString("minute_value", minuteValue);
                bundle.putString("audio_value", uniqueAudioID);


                intent1.putExtras(bundle);
                startActivity(intent1);
                return true;
            }
        });
    }

    private void setupMediaRecorder() {
        mediaRecorder = new MediaRecorder();
        mediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
        mediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
        mediaRecorder.setAudioEncoder(MediaRecorder.OutputFormat.AMR_NB);
        mediaRecorder.setOutputFile(pathSave);
    }

    private void requestPermission() {
        ActivityCompat.requestPermissions(this, new String[]{
                android.Manifest.permission.WRITE_EXTERNAL_STORAGE,
                android.Manifest.permission.RECORD_AUDIO
        }, REQUEST_PERMISSION_CODE);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case REQUEST_PERMISSION_CODE: {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED)
                    Toast.makeText(this, "Permission Granted", Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(this, "Permission Denied", Toast.LENGTH_SHORT).show();
            }
            break;
        }
    }

    private boolean checkPermissionFromDevice() {
        int write_external_storage_result = ContextCompat.checkSelfPermission(this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE);
        int record_audio_result = ContextCompat.checkSelfPermission(this, android.Manifest.permission.RECORD_AUDIO);
        return write_external_storage_result == PackageManager.PERMISSION_GRANTED &&
                record_audio_result == PackageManager.PERMISSION_GRANTED;

    }


    public boolean dispatchKeyEvent(KeyEvent event) {
        if (checkPermissionFromDevice()) {

            int action = event.getAction();
            int keyCode = event.getKeyCode();
            switch (keyCode) {
                case KeyEvent.KEYCODE_VOLUME_UP:
                    if (action == KeyEvent.ACTION_DOWN) {
                        pathSave = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + uniqueAudioID + "_audio_record.3gp";
                        //pathSave = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + UUID.randomUUID().toString() + "_audio_record.3gp";
                        setupMediaRecorder();
                        try {
                            mediaRecorder.prepare();
                            mediaRecorder.start();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        //playRecord.setEnabled(false);
                        mediaIsRecording = true;
                        Toast.makeText(this, "Recording.......", Toast.LENGTH_SHORT).show();
                    }
                    return true;
                case KeyEvent.KEYCODE_VOLUME_DOWN:
                    if (action == KeyEvent.ACTION_DOWN) {
                        if (mediaIsRecording == true) {
                            mediaRecorder.stop();
                            Toast.makeText(RecordDetailActivity.this, "Stopped Recording.......", Toast.LENGTH_SHORT).show();
                        }
                    }
                    return true;
                default:
                    return super.dispatchKeyEvent(event);
            }

        } else {
            requestPermission();
        }
        return true;
    }

    @Override
    protected void onStop() {
        super.onStop();

        if (tts != null) {
            tts.shutdown();
        }
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onRestart() {
        super.onRestart();
        finish();
        startActivity(getIntent());
    }


    private void mainSpeak() {
        String text = "Anda berada di halaman merekod  butiran. Halaman ini mengandungi 3 butang ..." +
                "butang halaman sebelumnya  yang terletak di bahagian atas skrin...... ... " +
                "butang  memain rekod  yang terletak di bahagian tengah  skrin dan ... " +
                "butang halaman seterusnya yang terletak di bahagian bawah skrin ..." +
                "sila tekan salah satu daripada butang ini untuk meneruskan...";
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null);
    }

    private void previousPageRecordSpeak() {
        String text = "Anda telah menekan butang untuk balik ke halaman sebelumnya.";
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null);
    }

    private void nextPageRecordSpeak() {
        String text = "Anda telah menekan butang halaman seterusnya  ...";
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null);
    }

    private void playRecordSpeak() {
        String text = "Anda telah menekan butang memainkan rekod  ...";
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null);
    }

    @Override
    public void onInit(int status) {
        if (status == TextToSpeech.SUCCESS) {
            int result = tts.setLanguage(new Locale("id", "ID"));
            if (result == TextToSpeech.LANG_NOT_SUPPORTED || result == TextToSpeech.LANG_MISSING_DATA) {
                Log.e("TTS", "This Language is not supported");
            } else {
                mainSpeak();
            }
        } else {
            Log.e("TTS", "Initialization_Failed");
        }

    }
}
