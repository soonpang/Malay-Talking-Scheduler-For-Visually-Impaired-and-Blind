package android_reside_menu.fyp_mts;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.speech.tts.TextToSpeech;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import java.util.Calendar;
import java.util.Locale;

import static android_reside_menu.fyp_mts.R.id.listView;

public class AppointmentReminderActivity extends AppCompatActivity implements TextToSpeech.OnInitListener {

    public String[] reminderArray = new String[]{"Tiada Peringatan", "10 minit", "20 minit", "30 minit", "45 minit", "1 jam", "2 jam", "3 jam", "6 jam",
            "12 jam", "1  hari", "", "", ""};
    ListView listViewDate;
    ArrayAdapter<String> adapter;
    private TextToSpeech tts;
    Button previousPageMinute;
    Button nextPageMinute;
    TextView emptyView;
    String yearValue;
    String monthValue;
    String dateValue;
    String hourValue;
    String minuteValue;
    String uniqueAudioID;
    String reminderValue = reminderArray[0];
    final static int req1 = 1;
    int yearInt;
    int monthInt;
    int dateInt;
    int hourInt;
    int minuteInt;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_appointment_reminder);

        adapter = new ArrayAdapter<String>(AppointmentReminderActivity.this, R.layout.row, reminderArray);
        listViewDate = (ListView) findViewById(listView);
        listViewDate.setAdapter(adapter);
        listViewDate.setEnabled(false);
        tts = new TextToSpeech(this, this);

        Bundle bundle = getIntent().getExtras();
        yearValue = bundle.getString("year_value");
        monthValue = bundle.getString("month_value");
        dateValue = bundle.getString("date_value");
        hourValue = bundle.getString("hour_value");
        minuteValue = bundle.getString("minute_value");
        uniqueAudioID = bundle.getString("audio_value");


        previousPageMinute = (Button) findViewById(R.id.button_previous);
        nextPageMinute = (Button) findViewById(R.id.button_next);
        emptyView = (TextView) findViewById(R.id.emptyView);


        emptyView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mainSpeak();
            }
        });


        previousPageMinute.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                previousPageReminderSpeak();
            }
        });

        previousPageMinute.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                finish();
                return true;
            }
        });

        nextPageMinute.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                nextPageReminderSpeak();
            }
        });

        nextPageMinute.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {

                Intent intent1 = new Intent(AppointmentReminderActivity.this, AppointmentSavedActivity.class);
                Bundle bundle = new Bundle();
                bundle.putString("year_value", yearValue);
                bundle.putString("month_value", monthValue);
                bundle.putString("date_value", dateValue);
                bundle.putString("hour_value", hourValue);
                bundle.putString("minute_value", minuteValue);
                bundle.putString("audio_value", uniqueAudioID);
                // bundle.putString("reminder_value", reminderValue);

                Calendar cal = Calendar.getInstance();

                yearInt = Integer.parseInt(yearValue);
                dateInt = Integer.parseInt(dateValue);
                hourInt = Integer.parseInt(hourValue);
                minuteInt = Integer.parseInt(minuteValue);

                String monthString = monthValue;

                if (monthString.equals("Januari")) {
                    monthInt = 0;
                } else if (monthString.equals("Februari")) {
                    monthInt = 1;
                } else if (monthString.equals("Mac")) {
                    monthInt = 2;
                } else if (monthString.equals("April")) {
                    monthInt = 3;
                } else if (monthString.equals("Mei")) {
                    monthInt = 4;
                } else if (monthString.equals("June")) {
                    monthInt = 5;
                } else if (monthString.equals("Julai")) {
                    monthInt = 6;
                } else if (monthString.equals("Ogos")) {
                    monthInt = 7;
                } else if (monthString.equals("September")) {
                    monthInt = 8;
                } else if (monthString.equals("Oktober")) {
                    monthInt = 9;
                } else if (monthString.equals("November")) {
                    monthInt = 10;
                } else if (monthString.equals("Disember")) {
                    monthInt = 11;
                }


                if (reminderValue.equals("Tiada Peringatan")) {
                    cal.set(Calendar.MINUTE, minuteInt);
                } else if (reminderValue.equals("10 minit")) {
                    if (minuteInt >= 10) {
                        int newMinuteInt = minuteInt - 10;
                        cal.set(Calendar.MINUTE, newMinuteInt);
                    } else {
                        cal.set(Calendar.HOUR_OF_DAY, hourInt - 1);
                        int totalMinutes = minuteInt + 59;
                        int newMinuteInt = totalMinutes - 10;
                        cal.set(Calendar.MINUTE, newMinuteInt);
                    }
                } else if (reminderValue.equals("20 minit")) {
                    if (minuteInt >= 20)
                        cal.set(Calendar.MINUTE, minuteInt - 20);
                    else {
                        cal.set(Calendar.HOUR_OF_DAY, hourInt - 1);
                        int totalMinutes = minuteInt + 59;
                        cal.set(Calendar.MINUTE, totalMinutes - 20);
                    }
                } else if (reminderValue.equals("30 minit")) {
                    if (minuteInt >= 30)
                        cal.set(Calendar.MINUTE, minuteInt - 30);
                    else {
                        cal.set(Calendar.HOUR_OF_DAY, hourInt - 1);
                        int totalMinutes = minuteInt + 59;
                        cal.set(Calendar.MINUTE, totalMinutes - 30);
                    }
                } else if (reminderValue.equals("45 minit")) {
                    if (minuteInt >= 45)
                        cal.set(Calendar.MINUTE, minuteInt - 45);
                    else {
                        cal.set(Calendar.HOUR_OF_DAY, hourInt - 1);
                        int totalMinutes = minuteInt + 59;
                        cal.set(Calendar.MINUTE, totalMinutes - 45);
                    }
                } else if (reminderValue.equals("1 jam")) {
                    if (hourInt >= 1)
                        cal.set(Calendar.HOUR_OF_DAY, hourInt - 1);
                    else {
                        cal.set(Calendar.DAY_OF_MONTH, dateInt - 1);
                        hourInt = 23;
                        cal.set(Calendar.HOUR_OF_DAY, hourInt - 1);
                    }
                } else if (reminderValue.equals("2  jam")) {
                    if (hourInt >= 2)
                        cal.set(Calendar.HOUR_OF_DAY, hourInt - 2);
                    else {
                        cal.set(Calendar.DAY_OF_MONTH, dateInt - 1);
                        hourInt = 23;
                        cal.set(Calendar.HOUR_OF_DAY, hourInt - 2);
                    }

                } else if (reminderValue.equals("6 jam")) {
                    if (hourInt >= 6)
                        cal.set(Calendar.HOUR_OF_DAY, hourInt - 6);
                    else {
                        cal.set(Calendar.DAY_OF_MONTH, dateInt - 1);
                        hourInt = 23;
                        cal.set(Calendar.HOUR_OF_DAY, hourInt - 6);
                    }
                } else if (reminderValue.equals("12  jam")) {
                    if (hourInt >= 12)
                        cal.set(Calendar.HOUR_OF_DAY, hourInt - 12);
                    else {
                        cal.set(Calendar.DAY_OF_MONTH, dateInt - 1);
                        hourInt = 23;
                        cal.set(Calendar.HOUR_OF_DAY, hourInt - 12);
                    }
                } else if (reminderValue.equals("1 hari")) {
                    if (dateInt >= 1)
                        cal.set(Calendar.DAY_OF_MONTH, dateInt - 1);
                    else {
                        cal.set(Calendar.MONTH, monthInt - 1);
                        int daysInMonth = cal.getActualMaximum(Calendar.DAY_OF_MONTH);
                        dateInt = daysInMonth;
                        cal.set(Calendar.DAY_OF_MONTH, dateInt - 1);

                    }
                }

                cal.set(Calendar.YEAR, yearInt);
                cal.set(Calendar.SECOND, 0);


                if (!reminderValue.equals("Tiada Peringatan")) {
                    Intent intent = new Intent(getBaseContext(), ReceiverActivity.class);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(getBaseContext(), req1, intent, PendingIntent.FLAG_UPDATE_CURRENT | Intent.FILL_IN_DATA);
                    AlarmManager alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);
                    alarmManager.set(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), pendingIntent);
                }

                //  setAlarm(cal);
                intent1.putExtras(bundle);
                startActivity(intent1);
                return true;
            }
        });
    }

    public boolean dispatchKeyEvent(KeyEvent event) {
        int action = event.getAction();
        int keyCode = event.getKeyCode();
        switch (keyCode) {
            case KeyEvent.KEYCODE_VOLUME_UP:
                if (action == KeyEvent.ACTION_DOWN) {
                    listViewDate = (ListView) findViewById(listView);
                    int firstVisibleItem = listViewDate.getFirstVisiblePosition();
                    if (firstVisibleItem != 0) {
                        int count1 = firstVisibleItem - 1;
                        if (count1 <= 0) {
                            listViewDate.setSelection(0);
                            tts.speak(reminderArray[0], TextToSpeech.QUEUE_FLUSH, null);
                            reminderValue = reminderArray[0];
                        } else {
                            listViewDate.setSelection(count1);
                            tts.speak(reminderArray[count1], TextToSpeech.QUEUE_FLUSH, null);
                            reminderValue = reminderArray[count1];
                        }
                    }
                }
                return true;
            case KeyEvent.KEYCODE_VOLUME_DOWN:
                if (action == KeyEvent.ACTION_DOWN) {
                    listViewDate = (ListView) findViewById(listView);

                    int count = 14;
                    int firstVisibleItem = listViewDate.getFirstVisiblePosition();
                    int lastVisibleCount = listViewDate.getLastVisiblePosition();
                    if (lastVisibleCount != count) {
                        int count1 = firstVisibleItem + 1;
                        if (count1 >= count) {
                            listViewDate.setSelection(count);
                            tts.speak(reminderArray[count], TextToSpeech.QUEUE_FLUSH, null);
                            reminderValue = reminderArray[count];
                        } else {
                            listViewDate.setSelection(count1);
                            tts.speak(reminderArray[count1], TextToSpeech.QUEUE_FLUSH, null);
                            reminderValue = reminderArray[count1];
                        }

                    }

                }
                return true;
            default:
                return super.dispatchKeyEvent(event);
        }
    }


    @Override
    protected void onStop() {
        super.onStop();

        if (tts != null) {
            tts.shutdown();
        }
    }


    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onRestart() {
        super.onRestart();
        finish();
        startActivity(getIntent());
    }

    private void mainSpeak() {
        String text = "Anda berada di halaman pilih peringatan. Halaman ini mengandungi 2 butang ..." +
                "butang halaman sebelumnya  yang terletak di bahagian atas skrin dan ... " +
                "butang halaman seterusnya yang terletak di bahagian bawah skrin ..." +
                "sila tekan salah satu daripada butang ini untuk meneruskan..." + "peringatan sekarang ialah" + reminderArray[0];
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null);
    }

    private void previousPageReminderSpeak() {
        String text = "Anda telah menekan butang untuk balik ke halaman sebelumnya.";
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null);
    }

    private void nextPageReminderSpeak() {
        String text = "Anda telah menekan butang halaman seterusnya  ...";
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null);
    }

    @Override
    public void onInit(int status) {
        if (status == TextToSpeech.SUCCESS) {
            int result = tts.setLanguage(new Locale("id", "ID"));
            if (result == TextToSpeech.LANG_NOT_SUPPORTED || result == TextToSpeech.LANG_MISSING_DATA) {
                Log.e("TTS", "This Language is not supported");
            } else {
                mainSpeak();
            }
        } else {
            Log.e("TTS", "Initialization_Failed");
        }

    }
}
