package android_reside_menu.fyp_mts;

import android.content.Context;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Calendar;
import java.util.Locale;

public class MainActivity extends AppCompatActivity implements TextToSpeech.OnInitListener {


    private TextToSpeech tts;
    private Button addNewAppBtn;
    private Button checkAppBtn;
    String yearValue;
    String monthValue;
    String dateValue;
    String hourValue;
    String minuteValue;
    String readDataValue = "";
    String dateTime;
    String uniqueAudioID;
    private SensorManager sm;
    TextView emptyView;

    private float acelVal;
    private float acelLast;
    private float shake;
    private static final String bmSave = "myFile.txt";
    private static final String TAG = MainActivity.class.getName();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        readFromFile();

        addNewAppBtn = (Button) findViewById(R.id.add_new);
        checkAppBtn = (Button) findViewById(R.id.check_appointment);
        emptyView = (TextView) findViewById(R.id.emptyView);

        tts = new TextToSpeech(this, this);

        sm = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        sm.registerListener(sensorListener, sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER), SensorManager.SENSOR_DELAY_NORMAL);
        acelVal = SensorManager.GRAVITY_EARTH;
        acelLast = SensorManager.GRAVITY_EARTH;
        shake = 0.00f;


        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            yearValue = bundle.getString("year_value");
            monthValue = bundle.getString("month_value");
            dateValue = bundle.getString("date_value");
            hourValue = bundle.getString("hour_value");
            minuteValue = bundle.getString("minute_value");
            uniqueAudioID = bundle.getString("audio_value");
        }


        emptyView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mainSpeak();
            }
        });
        addNewAppBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addAppSpeak();
            }
        });
        addNewAppBtn.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                startActivity(new Intent(MainActivity.this, SelectYearActivity.class));
                return true;
            }
        });
        checkAppBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAppSpeak();


            }
        });


        checkAppBtn.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {

                Bundle bundle = new Bundle();
                String checkIntent = "";
                if (readDataValue.equals(checkIntent)) {
                    Intent intent2 = new Intent(MainActivity.this, NoAppointmentActivity.class);
                    startActivity(intent2);

                } else {

                    Intent intent1 = new Intent(MainActivity.this, AppointmentListActivity.class);
                    bundle.putString("year_value", yearValue);
                    bundle.putString("month_value", monthValue);
                    bundle.putString("date_value", dateValue);
                    bundle.putString("hour_value", hourValue);
                    bundle.putString("minute_value", minuteValue);
                    bundle.putString("readData_value", readDataValue);
                    bundle.putString("audio_value", uniqueAudioID);

                    intent1.putExtras(bundle);
                    startActivity(intent1);
                }

                return true;
            }
        });


    }

    private String readFromFile() {

        String ret = "";

        try {
            InputStream inputStream = openFileInput(bmSave);

            if (inputStream != null) {
                InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
                BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
                String receiveString = "";
                StringBuilder stringBuilder = new StringBuilder();

                while ((receiveString = bufferedReader.readLine()) != null) {
                    stringBuilder.append(receiveString);
                    stringBuilder.append(System.getProperty("line.separator"));
                    System.out.println(stringBuilder.toString());

                }

                ret = stringBuilder.toString();
                inputStream.close();

            }
        } catch (FileNotFoundException e) {
            Log.e(TAG, "File not found: " + e.toString());
        } catch (IOException e) {
            Log.e(TAG, "Can not read file: " + e.toString());
        }
        readDataValue = ret;
        return readDataValue;
    }

    final SensorEventListener sensorListener = new SensorEventListener() {
        @Override
        public void onSensorChanged(SensorEvent sensorEvent) {
            float x = sensorEvent.values[0];
            float y = sensorEvent.values[1];
            float z = sensorEvent.values[2];

            acelLast = acelVal;
            acelVal = (float) Math.sqrt((double) (x * x + y * y + z * z));
            float delta = acelVal - acelLast;
            shake = shake * 0.9f + delta;

            Calendar cal = Calendar.getInstance();
            int checkHour = cal.get(Calendar.HOUR_OF_DAY);
            if (shake > 12) {


                String date = "" + cal.get(Calendar.DATE) + "-" + (cal.get(Calendar.MONTH) + 1) + "-" + cal.get(Calendar.YEAR);

                String time = "" + cal.get(Calendar.HOUR_OF_DAY) + ":" + cal.get(Calendar.MINUTE);

                if (checkHour == 0) {
                    String time12 = "" + 12 + ":" + cal.get(Calendar.MINUTE);
                    String dateTime = "tarikh hari ini ialah" + "" + date + ".... " + "masa sekarang ialah" + "...." + time12 + " " + "tengah malam";
                    tts.speak(dateTime, TextToSpeech.QUEUE_FLUSH, null);
                    Toast toast = Toast.makeText(getApplicationContext(), dateTime, Toast.LENGTH_SHORT);
                    toast.show();
                } else if (checkHour >= 1 && checkHour <= 12) {
                    String dateTime = "tarikh hari ini ialah" + "" + date + ".... " + "masa sekarang ialah" + "...." + time + " " + "pagi";
                    tts.speak(dateTime, TextToSpeech.QUEUE_FLUSH, null);
                    Toast toast = Toast.makeText(getApplicationContext(), dateTime, Toast.LENGTH_SHORT);
                    toast.show();
                } else if (checkHour >= 12 && checkHour < 16) {
                    if (checkHour == 13) {
                        time = "" + 1 + ":" + cal.get(Calendar.MINUTE);
                    } else if (checkHour == 14) {
                        time = "" + 2 + ":" + cal.get(Calendar.MINUTE);
                    } else if (checkHour == 15) {
                        time = "" + 3 + ":" + cal.get(Calendar.MINUTE);
                    }
                    String dateTime = "tarikh hari ini ialah" + "" + date + ".... " + "masa sekarang ialah" + "...." + time + " " + "tengah hari";
                    tts.speak(dateTime, TextToSpeech.QUEUE_FLUSH, null);
                    Toast toast = Toast.makeText(getApplicationContext(), dateTime, Toast.LENGTH_SHORT);
                    toast.show();
                } else if (checkHour >= 16 && checkHour < 21) {
                    if (checkHour == 16) {
                        time = "" + 4 + ":" + cal.get(Calendar.MINUTE);
                    } else if (checkHour == 17) {
                        time = "" + 5 + ":" + cal.get(Calendar.MINUTE);
                    } else if (checkHour == 18) {
                        time = "" + 6 + ":" + cal.get(Calendar.MINUTE);
                    } else if (checkHour == 19) {
                        time = "" + 7 + ":" + cal.get(Calendar.MINUTE);
                    } else if (checkHour == 20) {
                        time = "" + 8 + ":" + cal.get(Calendar.MINUTE);
                    }
                    String dateTime = "tarikh hari ini ialah" + "" + date + ".... " + "masa sekarang ialah" + "...." + time + " " + "petang";
                    tts.speak(dateTime, TextToSpeech.QUEUE_FLUSH, null);
                    Toast toast = Toast.makeText(getApplicationContext(), dateTime, Toast.LENGTH_SHORT);
                    toast.show();
                } else if (checkHour >= 21 && checkHour <= 24) {
                    if (checkHour == 21) {
                        time = "" + 9 + ":" + cal.get(Calendar.MINUTE);
                    } else if (checkHour == 22) {
                        time = "" + 10 + ":" + cal.get(Calendar.MINUTE);
                    } else if (checkHour == 23) {
                        time = "" + 11 + ":" + cal.get(Calendar.MINUTE);
                    } else if (checkHour == 24) {
                        time = "" + 12 + ":" + cal.get(Calendar.MINUTE);
                    }
                    dateTime = "tarikh hari ini ialah" + "" + date + ".... " + "masa sekarang ialah" + "...." + time + " " + "malam";
                    tts.speak(dateTime, TextToSpeech.QUEUE_FLUSH, null);
                    Toast toast = Toast.makeText(getApplicationContext(), dateTime, Toast.LENGTH_SHORT);
                    toast.show();
                }

            }

        }

        @Override
        public void onAccuracyChanged(Sensor sensor, int i) {

        }

    };

    @Override
    protected void onStop() {
        super.onStop();

        if (tts != null) {
            tts.shutdown();
        }
    }


    @Override
    public void onResume() {
        super.onResume();
        readFromFile();
    }

    @Override
    public void onRestart() {
        super.onRestart();
        finish();
        startActivity(getIntent());
    }

    private void mainSpeak() {
        String text = "Anda berada di halaman utama. Halaman ini mengandungi 2 butang ..." +
                "butang menambah pelantikan baru yang terletak di bahagian atas skrin dan ... " +
                "butang semak pelantikan yang terletak di bahagian bawah skrin ..." +
                "sila tekan salah satu daripada butang ini untuk meneruskan.";
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null);
    }

    private void addAppSpeak() {
        String text = "Anda telah menekan butang tambah pelantikan ...";
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null);
    }

    private void checkAppSpeak() {
        String text = "Anda telah menekan butang semak pelantikan  ...";
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null);
    }


    @Override
    public void onInit(int status) {
        if (status == TextToSpeech.SUCCESS) {

            int result = tts.setLanguage(new Locale("id", "ID"));
            if (result == TextToSpeech.LANG_NOT_SUPPORTED || result == TextToSpeech.LANG_MISSING_DATA) {
                Log.e("TTS", "This Language is not supported");
            } else {
                addNewAppBtn.setEnabled(true);
                mainSpeak();
            }
        } else {
            Log.e("TTS", "Initialization_Failed");
        }

    }


}


