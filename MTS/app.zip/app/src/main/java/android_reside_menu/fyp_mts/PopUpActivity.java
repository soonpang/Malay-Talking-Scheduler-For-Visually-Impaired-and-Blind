package android_reside_menu.fyp_mts;

import android.content.Intent;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Handler;
import android.os.HandlerThread;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.Button;


public class PopUpActivity extends AppCompatActivity {

    static boolean clicked = false;
    boolean playing = true;
    Button stopAlarm;
    Handler myHandler;
    HandlerThread readThread = new HandlerThread("");


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pop_up);

        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);

        int width = dm.widthPixels;
        int height = dm.heightPixels;
        getWindow().setLayout((int) (width), (int) (height));
        stopAlarm = (Button) findViewById(R.id.stopAlarmBtn);


        Uri alarmUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
        if (alarmUri == null) {
            alarmUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        }
        final Ringtone ringtone = RingtoneManager.getRingtone(this, alarmUri);

        readThread.start();
        myHandler = new Handler(readThread.getLooper());

        myHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                while (clicked == false) {
                    if (playing != clicked) {
                        stopAlarm.setEnabled(true);
                        ringtone.play();
                    } else if (clicked == true) {
                        stopAlarm.setEnabled(true);
                        readThread.quit();
                        break;
                    }
                }
            }
        }, 1000);

        stopAlarm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clicked = true;
                Intent intent1 = new Intent(PopUpActivity.this, MainActivity.class);
                startActivity(intent1);
            }
        });
    }
}
