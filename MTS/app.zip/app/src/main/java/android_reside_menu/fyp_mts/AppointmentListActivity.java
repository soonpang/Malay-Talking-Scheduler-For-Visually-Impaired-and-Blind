package android_reside_menu.fyp_mts;

import android.content.Intent;
import android.os.Environment;
import android.speech.tts.TextToSpeech;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

import static android_reside_menu.fyp_mts.R.id.listView;

public class AppointmentListActivity extends AppCompatActivity implements TextToSpeech.OnInitListener {

    Button backHomeBtn;
    Button proceedBtn;
    List<String> yearString = new ArrayList();
    List<String> monthString = new ArrayList();
    List<String> dateString = new ArrayList();
    List<String> timeString = new ArrayList();

    static List<String> sampleArray = new ArrayList<>();

    ListView listViewAppointment;
    ArrayAdapter<String> adapter;
    private TextToSpeech tts;
    String yearValue;
    String monthValue;
    String dateValue;
    String hourValue;
    String minuteValue;
    String readDataValue;
    String uniqueAudioID;
    String firstYearString;
    String firstMonthString;
    String firstDateString;
    String firstTimeString;
    int secondItemCounter = 0;
    static String appointmentListValue;
    int sampleArraySize;
    String getCount2Array;
    static List<String> newSampleArray;
    String selectedAppointmentValue;
    String hasAudioFile;
    TextView emptyView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_appointment_list);

        Bundle bundle = getIntent().getExtras();
        if (bundle.getString("readData_value") != null) {
            yearValue = bundle.getString("year_value");
            monthValue = bundle.getString("month_value");
            dateValue = bundle.getString("date_value");
            hourValue = bundle.getString("hour_value");
            minuteValue = bundle.getString("minute_value");
            readDataValue = bundle.getString("readData_value");
            uniqueAudioID = bundle.getString("audio_value");

        } else {
            Intent intent2 = new Intent(AppointmentListActivity.this, NoAppointmentActivity.class);
            startActivity(intent2);
        }
        StringBuilder sb = new StringBuilder(readDataValue);
        String[] dataStrings = sb.toString().split("\n");
        List<String> sampleArray = new ArrayList<String>(Arrays.asList(dataStrings));

        newSampleArray = sampleArray;
        newSampleArray.add("");
        newSampleArray.add("");
        newSampleArray.add("");


        String getFirstCountArray = newSampleArray.get(0);
        String firstAppointmentListValue = getFirstCountArray;
        selectedAppointmentValue = firstAppointmentListValue;

        for (String item : sampleArray) {
            String[] splitItems = item.split(" ");

            for (String secondItem : splitItems) {
                if (secondItemCounter == 0) {
                    dateString.add(secondItem);
                } else if (secondItemCounter == 1) {
                    monthString.add(secondItem);
                } else if (secondItemCounter == 2) {
                    yearString.add(secondItem);
                } else if (secondItemCounter == 3) {
                    timeString.add(secondItem);

                }
                secondItemCounter = secondItemCounter + 1;
            }

            secondItemCounter = 0;
        }

        firstYearString = yearString.get(0);
        firstMonthString = monthString.get(0);
        firstDateString = dateString.get(0);
        firstTimeString = timeString.get(0);


        sampleArraySize = sampleArray.size();



        adapter = new ArrayAdapter<String>(AppointmentListActivity.this, R.layout.row, sampleArray);
        listViewAppointment = (ListView) findViewById(listView);
        listViewAppointment.setAdapter(adapter);
        listViewAppointment.setEnabled(false);

        tts = new TextToSpeech(this, this);


        backHomeBtn = (Button) findViewById(R.id.returnBtn);
        proceedBtn = (Button) findViewById(R.id.proceedBtn);
        emptyView =(TextView) findViewById(R.id.emptyView);


        emptyView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mainSpeak();
            }
        });

        backHomeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                backHomeBtnSpeak();
            }
        });

        backHomeBtn.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                startActivity(new Intent(AppointmentListActivity.this, MainActivity.class));
                return true;
            }
        });

        proceedBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                proceedBtnSpeak();
            }
        });

        proceedBtn.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                Intent intent1 = new Intent(AppointmentListActivity.this, SelectedAppointmentActivity.class);
                Bundle bundle = new Bundle();


                String oriToBeRemoved = selectedAppointmentValue;
                String removeColon  = oriToBeRemoved.replaceAll("[:]", "");
                String removeSpace =removeColon.replaceAll("\\s+","");
                String finalString = removeSpace + "_audio_record.3gp";

                String pathFolder =  Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + removeSpace + "_audio_record.3gp";
                String selectedString =Environment.getExternalStorageDirectory().getAbsolutePath() + "/" +finalString ;

                if(pathFolder.equals(selectedString)){
                    bundle.putString("selected_audio_value", selectedString);
                    hasAudioFile = "true";
                    bundle.putString("has_audio_file", hasAudioFile);

                }else{
                   hasAudioFile = "false";
                    bundle.putString("has_audio_file", hasAudioFile);
                }
                bundle.putString("readData_value", readDataValue);
                bundle.putString("selected_appointment_value", selectedAppointmentValue);
                intent1.putExtras(bundle);
                startActivity(intent1);

                return true;
            }
        });


    }


    public boolean dispatchKeyEvent(KeyEvent event) {
        int action = event.getAction();
        int keyCode = event.getKeyCode();


        switch (keyCode) {
            case KeyEvent.KEYCODE_VOLUME_UP:
                if (action == KeyEvent.ACTION_DOWN) {
                    listViewAppointment = (ListView) findViewById(listView);
                    int firstVisibleItem = listViewAppointment.getFirstVisiblePosition();
                    if (firstVisibleItem != 0) {
                        int count1 = firstVisibleItem - 1;
                        if (count1 == 0) {
                            listViewAppointment.setSelection(0);
                            String getCountArray = newSampleArray.get(count1);
                            String speakRow = " tarikh" + " " + getCountArray + "   " + "minit";
                            tts.speak(speakRow, TextToSpeech.QUEUE_FLUSH, null);
                            appointmentListValue = getCountArray;
                            selectedAppointmentValue = appointmentListValue;
                        } else {
                            listViewAppointment.setSelection(count1);
                            String getCount1Array = newSampleArray.get(count1);
                            String speakRow = " tarikh" + " " + getCount1Array + "   " + "minit";
                            tts.speak(speakRow, TextToSpeech.QUEUE_FLUSH, null);
                            appointmentListValue = getCount1Array;
                            selectedAppointmentValue = appointmentListValue;
                        }
                    }
                }
                return true;
            case KeyEvent.KEYCODE_VOLUME_DOWN:
                if (action == KeyEvent.ACTION_DOWN) {
                    listViewAppointment = (ListView) findViewById(listView);

                    int count = sampleArraySize;
                    int firstVisibleItem = listViewAppointment.getFirstVisiblePosition();
                    int lastVisibleCount = listViewAppointment.getLastVisiblePosition();
                    if (sampleArraySize > 1) {  //to know got more than two rows
                        if (lastVisibleCount != count) {
                            int count1 = firstVisibleItem + 1;
                            if (count1 >= count) {
                                listViewAppointment.setSelection(count);
                                String getCountArray = newSampleArray.get(count);
                                String speakRow = " tarikh" + " " + getCountArray + "   " + "minit";
                                tts.speak(speakRow, TextToSpeech.QUEUE_FLUSH, null);
                                appointmentListValue = getCountArray;
                                selectedAppointmentValue = appointmentListValue;
                            } else {
                                listViewAppointment.setSelection(count1);
                                getCount2Array = newSampleArray.get(count1);
                                String speakRow = " tarikh" + " " + getCount2Array + "   " + "minit";
                                tts.speak(speakRow, TextToSpeech.QUEUE_FLUSH, null);
                                appointmentListValue = getCount2Array;
                                selectedAppointmentValue = appointmentListValue;
                            }

                        }
                    }
                }
                return true;
            default:
                return super.dispatchKeyEvent(event);
        }
    }

    private void mainSpeak() {
        String text = "Anda berada di halaman pilih pelantikan. Halaman ini mengandungi 2 butang ....." +
                "butang halaman utama  yang terletak di bahagian atas skrin dan ..... " +
                "butang halaman seterusnya yang terletak di bahagian bawah skrin ........" +
                "untuk memilih pelantikan silah gunakan butang bunyi atas dan bawah...." +
                "sila tekan salah satu daripada butang ini untuk meneruskan....." +
                "pelantikan sekarang ialah tarikh" + firstDateString + "    " + "Bulan" + firstMonthString + " " + "Tarikh" + firstYearString + " " + "Masa Sekarang adalah  pukul" + firstTimeString + "minit";
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null);
    }

    private void backHomeBtnSpeak() {
        String text = "Anda telah menekan butang untuk kembali ke halaman utama.";
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null);
    }

    private void proceedBtnSpeak() {
        String text = "Anda telah menekan butang untuk  ke halaman pelantikan yang dipilih.";
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null);
    }

    @Override
    protected void onStop() {
        super.onStop();

        if (tts != null) {
            tts.shutdown();
        }
    }

    @Override
    public void onResume()
    {
        super.onResume();
    }

    @Override
    public void onRestart()
    {
        super.onRestart();
        finish();
        startActivity(getIntent());
    }

    @Override
    public void onInit(int status) {
        if (status == TextToSpeech.SUCCESS) {
            int result = tts.setLanguage(new Locale("id", "ID"));
            if (result == TextToSpeech.LANG_NOT_SUPPORTED || result == TextToSpeech.LANG_MISSING_DATA) {
                Log.e("TTS", "This Language is not supported");
            }
            mainSpeak();
        } else {
            Log.e("TTS", "Initialization_Failed");
        }

    }
}
