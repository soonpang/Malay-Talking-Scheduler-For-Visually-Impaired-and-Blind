package android_reside_menu.fyp_mts;

import android.content.Intent;
import android.speech.tts.TextToSpeech;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import java.util.Locale;

import static android_reside_menu.fyp_mts.R.id.listView;

public class SelectMinuteActivity extends AppCompatActivity implements TextToSpeech.OnInitListener {
    public String[] minuteArray = new String[]{"0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19",
            "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39",
            "40", "41", "42", "43", "44", "45", "46", "47", "48", "49", "50", "51", "52", "53", "54", "55", "56", "57", "58", "59", "", "", ""};
    ListView listViewDate;
    ArrayAdapter<String> adapter;
    private TextToSpeech tts;
    Button previousPageMinute;
    Button nextPageMinute;
    TextView emptyView;
    String yearValue;
    String monthValue;
    String dateValue;
    String hourValue;
    String minuteValue = minuteArray[0];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_minute);

        adapter = new ArrayAdapter<String>(SelectMinuteActivity.this, R.layout.row, minuteArray);
        listViewDate = (ListView) findViewById(listView);
        listViewDate.setAdapter(adapter);
        listViewDate.setEnabled(false);
        tts = new TextToSpeech(this, this);

        Bundle bundle = getIntent().getExtras();
        yearValue = bundle.getString("year_value");
        monthValue = bundle.getString("month_value");
        dateValue = bundle.getString("date_value");
        hourValue = bundle.getString("hour_value");

        previousPageMinute = (Button) findViewById(R.id.button_previous);
        nextPageMinute = (Button) findViewById(R.id.button_next);
        emptyView = (TextView) findViewById(R.id.emptyView);


        emptyView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mainSpeak();
            }
        });

        previousPageMinute.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                previousPageYearSpeak();
            }
        });

        previousPageMinute.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                finish();
                return true;
            }
        });

        nextPageMinute.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                nextPageYearSpeak();
            }
        });

        nextPageMinute.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {

                Intent intent1 = new Intent(SelectMinuteActivity.this, RecordDetailActivity.class);
                Bundle bundle = new Bundle();
                bundle.putString("year_value", yearValue);
                bundle.putString("month_value", monthValue);
                bundle.putString("date_value", dateValue);
                bundle.putString("hour_value", hourValue);
                bundle.putString("minute_value", minuteValue);
                intent1.putExtras(bundle);
                startActivity(intent1);
                return true;
            }
        });
    }

    public boolean dispatchKeyEvent(KeyEvent event) {
        int action = event.getAction();
        int keyCode = event.getKeyCode();
        switch (keyCode) {
            case KeyEvent.KEYCODE_VOLUME_UP:
                if (action == KeyEvent.ACTION_DOWN) {
                    listViewDate = (ListView) findViewById(listView);
                    int firstVisibleItem = listViewDate.getFirstVisiblePosition();
                    if (firstVisibleItem != 0) {
                        int count1 = firstVisibleItem - 1;
                        if (count1 <= 0) {
                            listViewDate.setSelection(0);
                            tts.speak(minuteArray[0], TextToSpeech.QUEUE_FLUSH, null);
                            minuteValue = minuteArray[0];
                        } else {
                            listViewDate.setSelection(count1);
                            tts.speak(minuteArray[count1], TextToSpeech.QUEUE_FLUSH, null);
                            minuteValue = minuteArray[count1];
                        }
                    }
                }
                return true;
            case KeyEvent.KEYCODE_VOLUME_DOWN:
                if (action == KeyEvent.ACTION_DOWN) {
                    listViewDate = (ListView) findViewById(listView);

                    int count = 62;
                    int firstVisibleItem = listViewDate.getFirstVisiblePosition();
                    int lastVisibleCount = listViewDate.getLastVisiblePosition();
                    if (lastVisibleCount != count) {
                        int count1 = firstVisibleItem + 1;
                        if (count1 >= count) {
                            listViewDate.setSelection(count);
                            tts.speak(minuteArray[count], TextToSpeech.QUEUE_FLUSH, null);
                            minuteValue = minuteArray[count];
                        } else {
                            listViewDate.setSelection(count1);
                            tts.speak(minuteArray[count1], TextToSpeech.QUEUE_FLUSH, null);
                            minuteValue = minuteArray[count1];
                        }

                    }

                }
                return true;
            default:
                return super.dispatchKeyEvent(event);
        }
    }

    @Override
    protected void onStop() {
        super.onStop();

        if (tts != null) {
            tts.shutdown();
        }
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onRestart() {
        super.onRestart();
        finish();
        startActivity(getIntent());
    }

    private void mainSpeak() {
        String text = "Anda berada di halaman pilih minit. Halaman ini mengandungi 2 butang ..." +
                "butang halaman sebelumnya  yang terletak di bahagian atas skrin dan ... " +
                "butang halaman seterusnya yang terletak di bahagian bawah skrin ..." +
                "sila tekan salah satu daripada butang ini untuk meneruskan..." + "minit sekarang ialah" + minuteArray[0];
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null);
    }

    private void previousPageYearSpeak() {
        String text = "Anda telah menekan butang untuk balik ke halaman sebelumnya.";
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null);
    }

    private void nextPageYearSpeak() {
        String text = "Anda telah menekan butang halaman seterusnya  ...";
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null);
    }

    @Override
    public void onInit(int status) {
        if (status == TextToSpeech.SUCCESS) {
            int result = tts.setLanguage(new Locale("id", "ID"));
            if (result == TextToSpeech.LANG_NOT_SUPPORTED || result == TextToSpeech.LANG_MISSING_DATA) {
                Log.e("TTS", "This Language is not supported");
            } else {
                mainSpeak();
            }
        } else {
            Log.e("TTS", "Initialization_Failed");
        }

    }
}
