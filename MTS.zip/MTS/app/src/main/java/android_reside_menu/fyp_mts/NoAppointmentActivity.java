package android_reside_menu.fyp_mts;

import android.content.Intent;
import android.speech.tts.TextToSpeech;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import java.util.Locale;

public class NoAppointmentActivity extends AppCompatActivity implements TextToSpeech.OnInitListener {

    Button backHomeBtn;
    TextView emptyView;
    private TextToSpeech tts;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_no_appointment);
        tts = new TextToSpeech(this, this);


        emptyView = (TextView) findViewById(R.id.emptyView);


        backHomeBtn = (Button) findViewById(R.id.backHomeBtn);

        backHomeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mainSpeak();
            }
        });

        backHomeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                backHomeSpeak();
            }
        });

        backHomeBtn.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                Intent intent1 = new Intent(NoAppointmentActivity.this, MainActivity.class);
                startActivity(intent1);
                return true;
            }
        });
    }

    @Override
    protected void onStop() {
        super.onStop();

        if (tts != null) {
            tts.shutdown();
        }
    }

    private void mainSpeak() {
        String text = "Tidak pelantikan...sila menambah pelantikan baru " +
                "butang untuk kembali ke  halaman utama  terletak di bahagian bawah skrin ...";

        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null);
    }

    private void backHomeSpeak() {
        String text = "Anda telah menekan butang untuk balik ke halaman sebelumnya.";
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null);
    }

    @Override
    public void onInit(int status) {
        if (status == TextToSpeech.SUCCESS) {
            int result = tts.setLanguage(new Locale("id", "ID"));
            if (result == TextToSpeech.LANG_NOT_SUPPORTED || result == TextToSpeech.LANG_MISSING_DATA) {
                Log.e("TTS", "This Language is not supported");
            } else {
                mainSpeak();
            }
        } else {
            Log.e("TTS", "Initialization_Failed");
        }

    }
}
