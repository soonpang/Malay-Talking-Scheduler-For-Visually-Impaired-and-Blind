package android_reside_menu.fyp_mts;

import android.content.Intent;
import android.speech.tts.TextToSpeech;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import java.util.Locale;

import static android_reside_menu.fyp_mts.R.id.listView;

public class SelectHourActivity extends AppCompatActivity implements TextToSpeech.OnInitListener {
    public String[] hourArray = new String[]{"0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19",
            "20", "21", "22", "23", "", "", ""};
    ListView listViewDate;
    ArrayAdapter<String> adapter;
    private TextToSpeech tts;
    Button previousPageHour;
    Button nextPageHour;
    TextView emptyView;
    String yearValue;
    String monthValue;
    String dateValue;
    String hourValue = hourArray[0];


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_hour);

        adapter = new ArrayAdapter<String>(SelectHourActivity.this, R.layout.row, hourArray);
        listViewDate = (ListView) findViewById(listView);
        listViewDate.setAdapter(adapter);
        listViewDate.setEnabled(false);
        tts = new TextToSpeech(this, this);

        Bundle bundle = getIntent().getExtras();
        yearValue = bundle.getString("year_value");
        monthValue = bundle.getString("month_value");
        dateValue = bundle.getString("date_value");


        previousPageHour = (Button) findViewById(R.id.button_previous);
        nextPageHour = (Button) findViewById(R.id.button_next);
        emptyView = (TextView) findViewById(R.id.emptyView);


        emptyView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mainSpeak();
            }
        });

        previousPageHour.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                previousPageYearSpeak();
            }
        });

        previousPageHour.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                finish();
                return true;
            }
        });

        nextPageHour.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                nextPageYearSpeak();
            }
        });

        nextPageHour.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                Intent intent1 = new Intent(SelectHourActivity.this, SelectMinuteActivity.class);
                Bundle bundle = new Bundle();
                bundle.putString("year_value", yearValue);
                bundle.putString("month_value", monthValue);
                bundle.putString("date_value", dateValue);
                bundle.putString("hour_value", hourValue);
                intent1.putExtras(bundle);
                startActivity(intent1);
                return true;
            }
        });
    }

    public boolean dispatchKeyEvent(KeyEvent event) {
        int action = event.getAction();
        int keyCode = event.getKeyCode();
        switch (keyCode) {
            case KeyEvent.KEYCODE_VOLUME_UP:
                if (action == KeyEvent.ACTION_DOWN) {
                    listViewDate = (ListView) findViewById(listView);
                    int firstVisibleItem = listViewDate.getFirstVisiblePosition();
                    if (firstVisibleItem != 0) {
                        int count1 = firstVisibleItem - 1;
                        if (count1 <= 0) {
                            listViewDate.setSelection(0);
                            tts.speak(hourArray[0], TextToSpeech.QUEUE_FLUSH, null);
                            hourValue = hourArray[0];
                        } else {
                            listViewDate.setSelection(count1);
                            tts.speak(hourArray[count1], TextToSpeech.QUEUE_FLUSH, null);
                            hourValue = hourArray[count1];
                        }
                    }
                }
                return true;
            case KeyEvent.KEYCODE_VOLUME_DOWN:
                if (action == KeyEvent.ACTION_DOWN) {
                    listViewDate = (ListView) findViewById(listView);

                    int count = 26;
                    int firstVisibleItem = listViewDate.getFirstVisiblePosition();
                    int lastVisibleCount = listViewDate.getLastVisiblePosition();
                    if (lastVisibleCount != count) {
                        int count1 = firstVisibleItem + 1;
                        if (count1 >= count) {
                            listViewDate.setSelection(count);
                            tts.speak(hourArray[count], TextToSpeech.QUEUE_FLUSH, null);
                            hourValue = hourArray[count];
                        } else {
                            listViewDate.setSelection(count1);
                            tts.speak(hourArray[count1], TextToSpeech.QUEUE_FLUSH, null);
                            hourValue = hourArray[count1];
                        }

                    }

                }
                return true;
            default:
                return super.dispatchKeyEvent(event);
        }
    }


    @Override
    protected void onStop() {
        super.onStop();

        if (tts != null) {
            tts.shutdown();
        }
    }


    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onRestart() {
        super.onRestart();
        finish();
        startActivity(getIntent());
    }

    private void mainSpeak() {
        String text = "Anda berada di halaman pilih jam. Halaman ini mengandungi 2 butang ..." +
                "butang halaman sebelumnya  yang terletak di bahagian atas skrin dan ... " +
                "butang halaman seterusnya yang terletak di bahagian bawah skrin ..." +
                "sila tekan salah satu daripada butang ini untuk meneruskan..." + "jam sekarang ialah" + hourArray[0];
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null);
    }

    private void previousPageYearSpeak() {
        String text = "Anda telah menekan butang untuk balik ke halaman sebelumnya.";
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null);
    }

    private void nextPageYearSpeak() {
        String text = "Anda telah menekan butang halaman seterusnya  ...";
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null);
    }

    @Override
    public void onInit(int status) {
        if (status == TextToSpeech.SUCCESS) {
            int result = tts.setLanguage(new Locale("id", "ID"));
            if (result == TextToSpeech.LANG_NOT_SUPPORTED || result == TextToSpeech.LANG_MISSING_DATA) {
                Log.e("TTS", "This Language is not supported");
            } else {
                mainSpeak();
            }
        } else {
            Log.e("TTS", "Initialization_Failed");
        }

    }
}
