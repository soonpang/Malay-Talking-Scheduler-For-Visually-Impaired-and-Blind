package android_reside_menu.fyp_mts;

import android.content.Intent;
import android.speech.tts.TextToSpeech;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import java.util.Locale;

import static android_reside_menu.fyp_mts.R.id.listView;

public class SelectYearActivity extends AppCompatActivity implements TextToSpeech.OnInitListener {
    public String[] yearArray = new String[]{"2018", "2019", "2020", "2021", "2022", "2023", "2024", "2025", "2026", "2027", "", "", ""};
    ListView listViewYear;
    ArrayAdapter<String> adapter;
    private TextToSpeech tts;
    Button previousPageYear;
    Button nextPageYear;
    TextView emptyView;
    String yearValue = yearArray[0];


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_year);

        adapter = new ArrayAdapter<String>(SelectYearActivity.this, R.layout.row, yearArray);
        listViewYear = (ListView) findViewById(listView);
        listViewYear.setAdapter(adapter);
        listViewYear.setEnabled(false);
        tts = new TextToSpeech(this, this);

        previousPageYear = (Button) findViewById(R.id.button_previous);
        nextPageYear = (Button) findViewById(R.id.button_next);
        emptyView = (TextView) findViewById(R.id.emptyView);


        emptyView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mainSpeak();
            }
        });

        previousPageYear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                previousPageYearSpeak();
            }
        });

        previousPageYear.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                startActivity(new Intent(SelectYearActivity.this, MainActivity.class));
                return true;
            }
        });

        nextPageYear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                nextPageYearSpeak();


            }
        });

        nextPageYear.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                Intent intent1 = new Intent(SelectYearActivity.this, SelectMonthActivity.class);
                Bundle bundle = new Bundle();
                bundle.putString("year_value", yearValue);
                intent1.putExtras(bundle);
                startActivity(intent1);
                return true;
            }
        });


    }

    public boolean dispatchKeyEvent(KeyEvent event) {
        int action = event.getAction();
        int keyCode = event.getKeyCode();
        switch (keyCode) {
            case KeyEvent.KEYCODE_VOLUME_UP:
                if (action == KeyEvent.ACTION_DOWN) {
                    listViewYear = (ListView) findViewById(listView);
                    int firstVisibleItem = listViewYear.getFirstVisiblePosition();
                    if (firstVisibleItem != 0) {
                        int count1 = firstVisibleItem - 1;
                        if (count1 <= 0) {
                            listViewYear.setSelection(0);
                            tts.speak(yearArray[0], TextToSpeech.QUEUE_FLUSH, null);
                            yearValue = yearArray[0];
                        } else {
                            listViewYear.setSelection(count1);
                            tts.speak(yearArray[count1], TextToSpeech.QUEUE_FLUSH, null);
                            yearValue = yearArray[count1];
                        }
                    }
                }
                return true;
            case KeyEvent.KEYCODE_VOLUME_DOWN:
                if (action == KeyEvent.ACTION_DOWN) {
                    listViewYear = (ListView) findViewById(listView);

                    int count = 12;
                    int firstVisibleItem = listViewYear.getFirstVisiblePosition();
                    int lastVisibleCount = listViewYear.getLastVisiblePosition();
                    if (lastVisibleCount != count) {
                        int count1 = firstVisibleItem + 1;
                        if (count1 >= count) {
                            listViewYear.setSelection(count);
                            tts.speak(yearArray[count], TextToSpeech.QUEUE_FLUSH, null);
                            yearValue = yearArray[count];
                        } else {
                            listViewYear.setSelection(count1);
                            tts.speak(yearArray[count1], TextToSpeech.QUEUE_FLUSH, null);
                            yearValue = yearArray[count1];
                        }

                    }

                }
                return true;
            default:
                return super.dispatchKeyEvent(event);
        }
    }

    @Override
    protected void onStop() {
        super.onStop();

        if (tts != null) {
            tts.shutdown();
        }
    }

    @Override
    public void onRestart() {
        super.onRestart();
        finish();
        startActivity(getIntent());
    }


    @Override
    public void onResume() {  // After a pause OR at startup
        super.onResume();
        //Refresh your stuff here
    }

    private void mainSpeak() {
        String text = "Anda berada di halaman pilih tahun. Halaman ini mengandungi 2 butang ..." +
                "butang halaman sebelumnya  yang terletak di bahagian atas skrin dan ... " +
                "butang halaman seterusnya yang terletak di bahagian bawah skrin ..." +
                "sila tekan salah satu daripada butang ini untuk meneruskan..." + "tahun sekarang ialah" + yearArray[0];
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null);
    }

    private void previousPageYearSpeak() {
        String text = "Anda telah menekan butang untuk balik ke halaman sebelumnya.";
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null);
    }

    private void nextPageYearSpeak() {
        String text = "Anda telah menekan butang halaman seterusnya  ...";
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null);
    }

    @Override
    public void onInit(int status) {
        if (status == TextToSpeech.SUCCESS) {
            int result = tts.setLanguage(new Locale("id", "ID"));
            if (result == TextToSpeech.LANG_NOT_SUPPORTED || result == TextToSpeech.LANG_MISSING_DATA) {
                Log.e("TTS", "This Language is not supported");
            } else {
                mainSpeak();
            }
        } else {
            Log.e("TTS", "Initialization_Failed");
        }

    }
}
