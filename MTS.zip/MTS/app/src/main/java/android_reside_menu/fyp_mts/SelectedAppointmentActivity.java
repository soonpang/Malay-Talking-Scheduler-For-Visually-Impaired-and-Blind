package android_reside_menu.fyp_mts;

import android.content.Intent;
import android.media.MediaPlayer;
import android.speech.tts.TextToSpeech;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import java.io.IOException;
import java.util.Locale;

public class SelectedAppointmentActivity extends AppCompatActivity implements TextToSpeech.OnInitListener {

    private TextToSpeech tts;
    String selectedAppointmentValue;
    TextView currentAppointment;
    Button returnBtn;
    Button playRecord;
    Button previousBtn;
    TextView emptyView;
    String selectedString;
    String readDataValue;
    MediaPlayer mediaPlayer;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_selected_appointment);


        Bundle bundle = getIntent().getExtras();
        selectedAppointmentValue = bundle.getString("selected_appointment_value");
        selectedString = bundle.getString("selected_audio_value");
        readDataValue = bundle.getString("readData_value");


        currentAppointment = (TextView) findViewById(R.id.textView3);
        currentAppointment.setText(selectedAppointmentValue);


        returnBtn = (Button) findViewById(R.id.returnBtn);
        playRecord = (Button) findViewById(R.id.playRecord);
        previousBtn = (Button) findViewById(R.id.previousBtn);
        emptyView = (TextView) findViewById(R.id.emptyView);


        tts = new TextToSpeech(this, this);


        emptyView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mainSpeak();
            }
        });
        returnBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                backHomeBtnSpeak();
            }
        });

        returnBtn.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                startActivity(new Intent(SelectedAppointmentActivity.this, MainActivity.class));
                return true;
            }
        });

        playRecord.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                playRecordBtnSpeak();
            }
        });

        playRecord.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {

                mediaPlayer = new MediaPlayer();
                try {
                    mediaPlayer.setDataSource(selectedString);
                    mediaPlayer.prepare();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                mediaPlayer.start();
                return true;
            }
        });
        previousBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                previousRecordBtnSpeak();
            }
        });

        previousBtn.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                finish();
                return true;
            }
        });


    }

    private void mainSpeak() {
        String text = "Anda berada di halaman pelantikan yang dipilih. Halaman ini mengandungi 3 butang....." +
                "butang  halaman utama  yang terletak di bahagian atas skrin..... " +
                "butang memain rekod yang terletak di bahagian tengah skrin....." +
                "sila tekan salah satu daripada butang ini untuk meneruskan....." + "tarikh dan masa pelantikan ini ialah....." + selectedAppointmentValue;
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null);
    }

    private void backHomeBtnSpeak() {
        String text = "Anda telah menekan butang untuk kembali ke halaman utama.";
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null);
    }

    private void playRecordBtnSpeak() {
        String text = "Anda telah menekan butang memain pelantikan yang direkord.";
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null);
    }

    private void previousRecordBtnSpeak() {
        String text = "Anda telah menekan butang untuk balik ke halaman sebelumnya.";
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null);
    }

    @Override
    protected void onStop() {
        super.onStop();

        if (tts != null) {
            tts.shutdown();
        }
    }

    @Override
    public void onInit(int status) {
        if (status == TextToSpeech.SUCCESS) {
            int result = tts.setLanguage(new Locale("id", "ID"));
            if (result == TextToSpeech.LANG_NOT_SUPPORTED || result == TextToSpeech.LANG_MISSING_DATA) {
                Log.e("TTS", "This Language is not supported");
            }
            mainSpeak();
        } else {
            Log.e("TTS", "Initialization_Failed");
        }

    }
}
